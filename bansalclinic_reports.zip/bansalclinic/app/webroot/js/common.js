var host = window.location.host;
var proto = window.location.protocol;
var ajax_url = proto+"//"+host+"/~reforce/";
